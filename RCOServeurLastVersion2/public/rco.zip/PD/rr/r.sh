#!/usr/bin/env bash
echo pwd
node index.js
echo "done"
